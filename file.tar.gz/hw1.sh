#!/bin/bash

for i
do
    cat $i
done
